package com.smartpdf.arabic

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class MainActivity : Activity() {
    private var scannedPages = mutableListOf<Bitmap>()
    private lateinit var status: TextView

    private val camera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val bitmap = result.data?.extras?.get("data") as? Bitmap
            if (bitmap != null) {
                scannedPages.add(bitmap)
                status.text = "تمت إضافة صفحة. عدد الصفحات: ${scannedPages.size}"
            } else toast("تعذر الحصول على الصورة. جرّب اختيار صورة من الهاتف.")
        }
    }

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { uri ->
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)?.let { scannedPages.add(it) }
                }
            } catch (_: Exception) {}
        }
        status.text = "الصفحات المحددة: ${scannedPages.size}"
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            status.text = "تم اختيار ملف PDF. استخراج النص وتحويله إلى Word أو Excel يحتاج محرك OCR/استخراج مدمجاً؛ هذه النسخة الأولية لا تنفذ التحويل بعد."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.TOP
            setBackgroundColor(0xFFF5F7F6.toInt())
        }
        val title = TextView(this).apply {
            text = "المحوّل الذكي PDF"
            textSize = 25f
            setTextColor(0xFF174F45.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "مسح المستندات وحفظها بصيغة PDF"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        status = TextView(this).apply {
            text = "مرحباً! صوّر صفحاتك أو اختر صوراً من الهاتف."
            textSize = 14f
            setPadding(8, 18, 8, 18)
        }
        page.addView(title, match())
        page.addView(subtitle, match())
        addButton(page, "📷  مسح بالكاميرا", "التقط صورة للصفحة") {
            camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        }
        addButton(page, "🖼  اختيار صور من الهاتف", "إضافة صور متعددة إلى المستند") {
            imagePicker.launch("image/*")
        }
        addButton(page, "📄  إنشاء ملف PDF", "حفظ الصفحات المضافة كملف PDF") {
            createPdf()
        }
        addButton(page, "↔  PDF إلى Word", "تحويل المستند إلى DOCX") {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
        addButton(page, "▦  PDF إلى Excel", "استخراج الجداول إلى XLSX") {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
        addButton(page, "🗂  ملفاتي", "فتح مجلد المستندات المنشأة") {
            val dir = getExternalFilesDir(null)
            toast("مكان الملفات: ${dir?.absolutePath ?: filesDir.absolutePath}")
        }
        page.addView(status, match())
        val note = TextView(this).apply {
            text = "نسخة أولية: المسح وحفظ PDF يعملان محلياً. تحويل PDF إلى Word/Excel والتعرف العربي OCR لم يُدمجا بعد."
            textSize = 12f
            setTextColor(0xFF8A4B08.toInt())
            setPadding(4, 18, 4, 0)
        }
        page.addView(note, match())
        setContentView(page)
    }

    private fun addButton(parent: LinearLayout, label: String, desc: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$label\n$desc"
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 })
    }

    private fun createPdf() {
        if (scannedPages.isEmpty()) {
            toast("أضف صفحة بالكاميرا أو اختر صورة أولاً.")
            return
        }
        try {
            val doc = PdfDocument()
            scannedPages.forEachIndexed { index, bitmap ->
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, index + 1).create()
                val page = doc.startPage(pageInfo)
                val scaled = Bitmap.createScaledBitmap(bitmap, 555, 785, true)
                page.canvas.drawBitmap(scaled, null, Rect(20, 28, 575, 813), null)
                doc.finishPage(page)
            }
            val outDir = getExternalFilesDir(null) ?: filesDir
            val out = File(outDir, "SmartPDF_${System.currentTimeMillis()}.pdf")
            FileOutputStream(out).use { doc.writeTo(it) }
            doc.close()
            status.text = "تم إنشاء PDF بنجاح:\n${out.absolutePath}"
            scannedPages.clear()
            toast("تم حفظ ملف PDF")
        } catch (e: Exception) {
            toast("حدث خطأ أثناء إنشاء PDF: ${e.localizedMessage}")
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
